package com.yangdai.calc.utils;

/**
 * @author 30415
 */
public interface TTSInitializationListener {
    void onTTSInitialized(boolean isSuccess);
}
