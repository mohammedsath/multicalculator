package com.yangdai.calc.main.calculator;

/**
 * @author 30415
 */
public interface HistoryItemClick {
    void onClick(String str);
}
