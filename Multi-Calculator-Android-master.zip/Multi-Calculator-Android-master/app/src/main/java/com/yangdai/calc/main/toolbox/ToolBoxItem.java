package com.yangdai.calc.main.toolbox;

import android.graphics.drawable.Drawable;

/**
 * @author 30415
 */
public record ToolBoxItem(int id, String title, Drawable drawable) {
}
